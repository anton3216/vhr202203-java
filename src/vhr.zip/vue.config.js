let proxyObject = {};
// 所有请求都经过代理对象
proxyObject['/'] = {
  target : 'localhost:9999',// 代理目标
  ws : false ,//关闭websocket
  changeOrigin : true,
  pathRewrite : {
      '^/' : '' // 不重写地址
  }
}
