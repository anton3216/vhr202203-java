import axios from 'axios';
import {
  Message
} from 'element-ui';
const http = {};

axios.interceptors.response.use(
  success => {
    // 因为后端代码通过HTTP协议返回的代码是200
    // 所以在我们看来即使是登录异常返回的status也是200
    // 所以我们需要在这些200中找出我们自己定义的500
    // 1. success对象中有这个status属性
    // 2. success对象中有这个status属性的值是 200
    // 3. 我们自己响应的数据(data)中status是500
    if (success.status && success.status == 200 && success.data.status == 500) {
      // 待测试
      message.error(success.data.msg);
      return;
    }
    if (success.data.msg) {
      message.success(success.data.msg);
    }
  },
  error => {
    if (error.response.status == 504 || error.response.status == 404) {
      message.error('ORZ,服务器被吃了');
    } else if (error.response.status == 403) {
      message.error('没有权限,请联系管理员处理!');
    } else if (error.response.status == 401) {
      message.error('没有登录,请登录!');
    } else {
      if (error.response.data.msg) {
        Message.error(error.response.data.msg);
      } else {
        Message.error('未知错误');
      }
    }
  });

let pirfix = '';

http.postKeyValueRequest = function (url,params) {
  return axios({
    method : 'post',
    url : '${pirfix}${url}',
    data : params
  })
}

// 封装登录请求使用的axios
export default http;
